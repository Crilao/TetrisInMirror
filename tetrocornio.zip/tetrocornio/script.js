//=== Canvas Principal ===
let lastTime = 0;
let dropInterval = 1000;
let dropCounter = 0;
const can = document.getElementById("canvasDaRapaziada");
const con = can.getContext("2d");
can.width = 250;
can.height = 500;
con.scale(25, 25);
var verificaTamanho = true;
var largura = 3;
var altura = 19;
var mtx = null;
var mtx2 = null;
var numero = 10;
var tamTabule = 20;
var tabuleiro = populaArrayMatriz(numero, tamTabule);
var pontuacao = 0;
var linhas = 0;
var linhasBonus = 0;
var pausa = 0;
var nivel = document.getElementById("nivel");
var contaNivel = 1;
var contLvl = 0;
var top5 = [
  [0, "", 0, 0, 0],
  [0, "", 0, 0, 0],
  [0, "", 0, 0, 0],
  [0, "", 0, 0, 0],
  [0, "", 0, 0, 0],
];

var gradient = con.createLinearGradient(0, 0, 170, 0);
gradient.addColorStop("0", "magenta");
gradient.addColorStop("0.2" ,"blue");

//=== Canvas proxPeca ===
const canProxPeca = document.getElementById("canvasProxPeca");
const conProxPeca = canProxPeca.getContext("2d");
canProxPeca.width = 250;
conProxPeca.height = 100;
conProxPeca.scale(25, 25);

function desenhaProxPeca(matriz){
  for (var i = 0; i < matriz.length; i++) {
    for (var j = 0; j < matriz[i].length; j++) {
      if (matriz[i][j] !== 0) { //TLJICQ
        if (matriz[i][j] == 1) {
          conProxPeca.fillStyle = '#ff1100';
        } else if (matriz[i][j] == 2) {
          conProxPeca.fillStyle = '#025e3e';
        } else if (matriz[i][j] == 3) {
          conProxPeca.fillStyle = '#1cd44a';
        } else if (matriz[i][j] == 4) {
          conProxPeca.fillStyle = '#00e1ff';
        } else if (matriz[i][j] == 5) {
          conProxPeca.fillStyle = '#1900ff';
        } else if (matriz[i][j] == 6) {
          conProxPeca.fillStyle = '#f5a020';
        }
        conProxPeca.fillRect(j + 2 , i + 2, 1, 1);
      }
    }
  }
}

function limpaProxPeca(){
  conProxPeca.fillStyle = "white";
  conProxPeca.fillRect(0, 0, canProxPeca.width, canProxPeca.height);
}

//nome do jogador, pontuação obtida, nível atingido e tempo de duração da partida

function mudaTamanho() {
  if (verificaTamanho) {
    largura = 10;
    altura = 41;
    tamTabule = 44;
    numero = 22;
    can.width = 550;
    can.height = 1100;
    verificaTamanho = false;
  } else {
    largura = 3;
    altura = 17;
    tamTabule = 20;
    can.width = 250;
    can.height = 500;
    numero = 10;
    verificaTamanho = true;
  }
  tabuleiro = populaArrayMatriz(numero, tamTabule);
  con.scale(25, 25);
  desenhaTabuleiro();
}

function populaArrayMatriz(tamanho, tamTabule) {
  const vetor = [];
  for (var i = 0; i < tamTabule; i++) {
    vetor.push(new Array(tamanho).fill(0));
  }
  return vetor;
}

function desenhaMatrizCanvas(matriz, largura, altura) {
  for (var i = 0; i < matriz.length; i++) {
    for (var j = 0; j < matriz[i].length; j++) {
      if (matriz[i][j] !== 0) {
        if (matriz[i][j] == 1) {
          con.fillStyle = '#ff1100';
        } else if (matriz[i][j] == 2) {
          con.fillStyle = '#025e3e';
        } else if (matriz[i][j] == 3) {
          con.fillStyle = '#1cd44a';
        } else if (matriz[i][j] == 4) {
          con.fillStyle = '#00e1ff';
        } else if (matriz[i][j] == 5) {
          con.fillStyle = '#1900ff';
        } else if (matriz[i][j] == 6) {
          con.fillStyle = '#f5a020';
        }
        con.fillRect(j + largura, i + altura, 1, 1);
      }
    }
  }
}
//====Limpa Matriz principal====
function limpaTabuleiro() {
  tabuleiro = populaArrayMatriz(numero, tamTabule);
  desenhaTabuleiro();
  const peca = 'TLJICQ';
  dropInterval = 1000;
  mtx2 = populaMatrizPeca(peca[peca.length * Math.random() | 0]);
  pontuacao = 0;
  linhas = 0;
  document.getElementById("pontuacao").innerHTML = "Pontos: " + pontuacao;
  document.getElementById("linhas").innerHTML = "Linhas: " + linhas;
  if (verificaTamanho) {
    largura = 4;
    altura = 17;
  } else {
    largura = 10;
    altura = 41;
  }
  update();
}

//========PEÇAS==========
function populaMatrizPeca(peca) {
  switch (peca) {
    case 'T':
      return [
        [0, 0, 0],
        [1, 1, 1],
        [0, 1, 0]
      ];
      break;
    case 'L':
      return [
        [0, 2, 0],
        [0, 2, 0],
        [0, 2, 2]
      ];
      break;
    case 'J':
      return [
        [0, 3, 0],
        [0, 3, 0],
        [3, 3, 0]
      ];
      break;
    case 'I':
      return [
        [0, 4, 0, 0],
        [0, 4, 0, 0],
        [0, 4, 0, 0],
        [0, 4, 0, 0],
      ];
      break;
    case 'C':
      return [
        [0, 0, 0],
        [5, 5, 5],
        [5, 0, 5]
      ];
      break;
    case 'Q':
      return [
        [0, 0, 0, 0],
        [0, 6, 6, 0],
        [0, 6, 6, 0],
        [0, 0, 0, 0]
      ];
      break;
  }
}
//========FIM PEÇAS==========

function limparLinha() {
  verifica:
  for (let y = 0; y < tabuleiro.length; ++y) {
    for (let x = 0; x < tabuleiro[y].length; ++x) {
      if (tabuleiro[y][x] === 0)
        continue verifica;
    }
    const linha = tabuleiro.splice(y, 1)[0].fill(0);
    tabuleiro.push(linha);
    --y;
    linhasBonus += 1;
    linhas += 1;
  }
}

function desenhaTabuleiro() {
  con.fillStyle = "white";
  con.fillRect(0, 0, can.width, can.height);
  desenhaMatrizCanvas(tabuleiro, 0, 0);
  desenhaMatrizCanvas(mtx, largura, altura);
  quadriculado();
}

//====Quadricula o Canvas
function quadriculado() {
  con.strokeStyle = gradient;
  con.strokeRect(0, 0, 10, 20);

  for (x = 0; x < 22; x++) {
    con.beginPath();
    con.moveTo(x, 0);
    con.lineTo(x, 44);
    con.stroke();
    con.lineWidth = 0.08;
  }

  for (y = 1; y < 44; y++) {
    for (x = 0; x <= 22; x++) {
      con.beginPath();
      con.moveTo(x, y);
      con.lineTo(1, y);
      con.stroke();
      con.lineWidth = 0.08;
    }

  }
}

function update(time = 0) {
  if (verificaTamanho) {
    if (tabuleiro[19][4] != 0 || tabuleiro[19][5] != 0) {
      chamaRanking();
      limpaTabuleiro();
      zeraCronometro();
      return;
    }
  } else {
    if (tabuleiro[43][10] != 0 || tabuleiro[43][11] != 0) {
      chamaRanking();
      limpaTabuleiro();
      zeraCronometro();
      return;
    }
  }

  const deltaTime = time - lastTime;
  lastTime = time;
  dropCounter += deltaTime;
  if (dropCounter > dropInterval) {
    rapido();
    dropCounter = 0;
  }
  desenhaTabuleiro();
  requestAnimationFrame(update);
}

function verificaColisao(tabuleiro, mtx, largura, altura) {
  const matriz = mtx;
  const deslocaX = largura;
  const deslocaY = altura;

  for (let y = 0; y < matriz.length; y++) {
    for (let x = 0; x < matriz[y].length; x++) {
      if (matriz[y][x] !== 0 && (tabuleiro[y + deslocaY] && tabuleiro[y + deslocaY][x + deslocaX]) !== 0) {
            return true;
      }
    }
  }
  return false;
}

function trocaValorTabuleiro(tabuleiro, mtx, largura, altura) {
  mtx.forEach((line, y) => {
    line.forEach((value, x) => {
      if (value !== 0) {
        tabuleiro[y + altura][x + largura] = value;
      }
    });
  });
}

function rapido() {
  if (pausa == 0) {
    altura--;
    if (verificaColisao(tabuleiro, mtx, largura, altura)) {
      altura++;
      trocaValorTabuleiro(tabuleiro, mtx, largura, altura);
      mtx = mtx2;
      mtx2 = populaMatrizPeca(peca[peca.length * Math.random() | 0]);
      limpaProxPeca(mtx2);
      desenhaProxPeca(mtx2);
      if (verificaTamanho) {
        largura = 4;
        altura = 17;
      } else {
        largura = 10;
        altura = 41;
      }
      limparLinha();
      if (linhasBonus > 0) {
        pontuacao += (linhasBonus * 10) * (linhasBonus);
        document.getElementById("pontuacao").innerHTML = "Pontos: " + pontuacao;
        document.getElementById("linhas").innerHTML = "Linhas: " + linhas;
        linhasBonus = 0;
        aumentaNivel();
      }
    }
    dropCounter = 0;
  }
}
//Atualiza nivel
function aumentaNivel() {
  if (pontuacao >= 500 && pontuacao < 1000 && contLvl === 0) {
    dropInterval -= 200;
    contLvl++;
    contaNivel++;
    nivel.innerHTML = contaNivel;
  } else if (pontuacao >= 1000 && pontuacao < 1500 && contLvl === 1) {
    dropInterval -= 200;
    contLvl++;
    contaNivel++;
    nivel.innerHTML = contaNivel;
  } else if (pontuacao >= 1500 && pontuacao < 2000 && contLvl === 2) {
    dropInterval -= 200;
    contLvl++;
    contaNivel++;
    nivel.innerHTML = contaNivel;
  } else if (pontuacao >= 2000 && pontuacao < 2500 && contLvl === 3) {
    dropInterval -= 200;
    contLvl++;
    contaNivel++;
    nivel.innerHTML = contaNivel;
  }
}

function movimentaPeca(sentido) {
  largura += sentido;
  if (verificaColisao(tabuleiro, mtx, largura, altura)) {
    largura -= sentido;
  }
}

function rotaciona() {
  const pos = largura;
  let anda = 1;
  rotacao(mtx);
  while (verificaColisao(tabuleiro, mtx, largura, altura)) {
    largura += anda;
    anda = -(anda + (anda > 0 ? 1 : -1));
    if (anda > mtx[0].length) {
      rotacao(mtx);
      largura = pos;
      return;
    }
  }
}

//O método reverse() inverte os itens de um array.
function rotacao(mtx) {
  for (let y = 0; y < mtx.length; y++) {
    for (let x = 0; x < y; x++) {
      [mtx[x][y], mtx[y][x]] = [mtx[y][x], mtx[x][y]];

    }
  }
  mtx.forEach(line => line.reverse());
}

//========BOTÕES==========
document.addEventListener("keydown", callback);

function callback(event) {
  if (event.keyCode == 37 || event.keyCode == 65) {
    movimentaPeca(-1);
    event.preventDefault();
  }
  else if (event.keyCode == 38 || event.keyCode == 87) {
    rapido();
    event.preventDefault();
  }
  else if (event.keyCode == 39 || event.keyCode == 68) {
    movimentaPeca(1);
    event.preventDefault();
  }
  else if (event.keyCode == 40 || event.keyCode == 83) {
    rotaciona();
    event.preventDefault();
  }
  else if (event.keyCode == 80 || event.keyCode == 32) {
    pausa = 1 - pausa;
  }
}
//========FIM BOTÕES==========

//========RANKING==========
function chamaRanking() {
  do {
    var nomeJogador = prompt("Game Over! Digite o seu nome", "Player");
  } while (nomeJogador == "");

  var pos = -1;

  for (var i = 0; i < 5 && pos == -1; i++) {
    if (pontuacao > top5[i][2] || top5[i][0] == 0) //
      var pos = i;
  }

  var aux = [0, '', 0, 0, 0];

  for (var j = 0; j < 5; j++) {
    switch (j) {
      case 0: aux[j] = pos + 1; break;
      case 1: aux[j] = nomeJogador; break;
      case 2: aux[j] = pontuacao; break;
      case 3: aux[j] = contaNivel; break;
      case 4: aux[j] = tempo; break;
      default: break;
    }
  }

  top5.splice(pos, 0, aux);


  document.getElementById("rank").innerHTML = "";

  for (var i = 0; i < 5 && top5[i][0] != 0; i++) {
    top5[i][0] = i + 1;

    document.getElementById("rank").innerHTML = document.getElementById("rank").innerHTML + "#" + top5[i][0] + " | Nome: " + top5[i][1] + " | Pontos: " + top5[i][2] + " | Nível: " + top5[i][3] + " | " + top5[i][4] + "ms<br>-----------<br>";
  }
  pontuacao = 0;
  linhas = 0;
  return;
}
//====FIM RANKING====

//====CRONOMETRO====
var decimos = 0, segundos = 0, minutos = 0, horas = 0, tempo = 0, t;

function adicionar() {
  tempo += 100;
  decimos++;

  if (decimos >= 10) {
    decimos = 0;
    segundos++;
    if (segundos >= 60) {
      segundos = 0;
      minutos++;
      if (minutos >= 60) {
        minutos = 0;
        horas++;
      }
    }
  }

  document.getElementById("cronometro").innerHTML = "Tempo: " + horas + ":" + minutos + ":" + segundos + "\"" + decimos;

  cronometro();
}

function cronometro() {
  t = setTimeout(adicionar, 100);
}

function zeraCronometro() {
  decimos = 0, segundos = 0, minutos = 0, horas = 0, tempo = 0;
}

cronometro();
//====FIM CRONOMETRO====
const peca = 'TLJICQ'; 
mtx = populaMatrizPeca(peca[peca.length * Math.random() | 0]);
largura = 4;
altura = 17;
update();
mtx2 = populaMatrizPeca(peca[peca.length * Math.random() | 0]);
largura = 4;
altura = 17;
desenhaProxPeca(mtx2);
